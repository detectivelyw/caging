#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    printf("--beginning of program-- \n");

    int counter = 0;
    pid_t pid = fork();

    if (pid == 0)
    {
        // child process
        int i;
        for (i = 0; i < 5; i++)
        {
            printf("[child process %d]: counter = %d \n", pid, ++counter);
        }
    }
    else if (pid > 0)
    {
        // parent process
        int j;
        for (j = 0; j < 5; j++)
        {
            printf("[parent process %d]: counter = %d \n", pid, ++counter);
        }
    }
    else
    {
        // fork failed
        printf("fork() failed! \n");
        return 1;
    }

    printf("--end of program-- \n");

    return 0;
}
