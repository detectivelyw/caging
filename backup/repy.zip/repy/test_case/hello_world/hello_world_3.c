#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{  
    printf("<cage 3> Hello World! 03\n");
    return 0;
}
