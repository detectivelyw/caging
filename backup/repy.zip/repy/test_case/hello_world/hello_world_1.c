#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{   
    printf("<cage 1> Hello World! 01\n");
    return 0;
}
