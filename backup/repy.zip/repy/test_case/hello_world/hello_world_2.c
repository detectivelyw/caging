#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{  
    printf("<cage 2> Hello World! 02\n");
    return 0;
}
