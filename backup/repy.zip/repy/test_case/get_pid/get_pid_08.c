#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    // linddata.420
    pid_t pid = getpid();
    fprintf(stdout, "This is the second time.\n");
    fprintf(stdout, "Current process id number is: %d \n", pid);

    return 0;
}
