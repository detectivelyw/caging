#include <math.h>
#include <stdio.h>
int main(void)
{
  printf("powl(3.2, 1.0) = %Lf\n", powl(3.2, 1.0));  
  return 0;
}
