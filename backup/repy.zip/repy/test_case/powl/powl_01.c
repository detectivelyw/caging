#include <math.h>
#include <stdio.h>
int main(void)
{
  printf("ieee754_powl(3.2, 1.0) = %Lf\n", ieee754_powl(3.2, 1.0));  
  return 0;
}
