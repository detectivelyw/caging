#pragma repy

getruntime()
