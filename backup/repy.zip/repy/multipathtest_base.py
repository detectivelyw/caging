dy_import_module_symbols("multipathtest_helper")

launch_test("(MultiPathShim,(NoopShim))")
